# Propiedades de vistas y elementos

<!-- VIGENCIA_DOC23_20261018 -->
**Corte de referencia: 18/10/2026, candidata 1.5.395; entrega activa 1.5.242.** La candidata no sustituye la instalación activa. Los cambios nuevos requieren su propia compilación y pruebas. Los [26 pendientes y sus criterios](AVANCE_26_PENDIENTES.md) son la lista de continuidad; esta revisión de guías corresponde al n.º 23 y no cierra los otros requisitos.
<!-- FIN_VIGENCIA_DOC23_20261018 -->

La paleta **Propiedades** sigue la selección de la vista activa. Al hacer clic en el fondo sin seleccionar elementos, vuelve a mostrar la vista. Al seleccionar varios elementos, muestra sus propiedades comunes; **<varía>** indica valores diferentes. Cambiar una propiedad común modifica todos los elementos seleccionados.

## Configurar una vista

Cada pestaña conserva su propio zoom, posición, orientación y configuración. Al cambiar de pestaña o abrir una vista existente desde el navegador, la paleta corresponde a esa vista. Crear otra vista conserva los ajustes de las que ya están abiertas.

La ficha activa permanece blanca. Fichas inactivas, franja libre y desplegable usan gris RGB(224,224,224), con borde naranja de foco. Las cabeceras de herramientas y el pie claro de Propiedades ya tienen el diseño corporativo aprobado. La comprobación en otras escalas y monitores continúa pendiente.

- **Gráficos:** escala en formato `1:100`, detalle, visibilidad de piezas, disciplina, estilo visual, opciones de diseño, líneas ocultas, sol y sombras. Escala y detalle se sincronizan con los controles inferiores.
- **Modificaciones de visibilidad/gráficos → Editar:** visibilidad, color, transparencia, grosor y semitono por categoría. El botón **X** junto al color recupera el color propio de los objetos de esa categoría. **Restablecer categorías** restablece todas las categorías del formulario.
- **Opciones de visualización → Editar:** estilo, detalle, aristas, suavizado, transparencia, iluminación, fondo, sol y sombras.
- **Extensión:** recorte, región visible, recorte de anotaciones, delimitación lejana, caja de referencia y caja de sección.
- **Cámara:** proyección, orientación, elevaciones y planos de delimitación. Las distancias usan las unidades del modelo. En perspectiva, el límite lejano debe superar el plano cercano manual.
- **Datos de identidad:** nombre, título en plano y plantilla. El título se conserva como dato de la vista; no crea una lámina.
- **Proceso por fases:** fase y filtro de fases.
- **Otros:** guardar y cargar la configuración de la vista.

En el formulario de configuración, **Aplicar** confirma los cambios y mantiene el formulario abierto; **Aceptar** confirma y cierra; **Cancelar** descarta los cambios que aún no se hayan aplicado. Se puede cambiar de página sin perder la edición pendiente. La rueda desplaza la paleta sin cambiar accidentalmente las listas cerradas.

## Fases, alternativas y piezas

Cada elemento puede tener disciplina, fase de creación, fase de demolición, opción de diseño y detalle mínimo visible. La vista usa esos valores para filtrar el dibujo y la selección. Las opciones disponibles inicialmente son tres fases —Existente, Nueva construcción y Futuro— y Modelo base más tres alternativas. Los elementos del modelo base permanecen visibles al elegir una alternativa.

En una extrusión seleccionada, **Crear piezas** construye dos mitades a lo largo de su extrusión. Las piezas tienen geometría e identidad propias y conservan el vínculo al original. Al reconstruir la extrusión original se actualizan ambas mitades. **Mostrar original**, **Mostrar piezas** y **Mostrar ambos** controlan qué representación muestra cada vista. Esta herramienta de división inicial no admite todavía divisiones arbitrarias de cualquier sólido.

## Guardar configuraciones

**Guardar configuración de vista** genera un archivo `.tramavista` (también lee los anteriores `.cobravista`). Conserva los ajustes de la vista, incluidos cámara, filtros y modificaciones por categoría. **No guarda la geometría ni sustituye un archivo de proyecto.** La carga valida el documento antes de aplicarlo y restablece la configuración anterior si falla la aplicación.

El proyecto tradicional `.tramaproyecto` conserva las formas y metadatos soportados, referencias, vistas, imágenes, cámaras/recorridos y planos. Su apertura importa sobre la sesión actual y no ofrece rollback global ni recuperación completa del espacio de trabajo. Los flujos completos `.ptrm/.ctrm` y el aislamiento multiproyecto siguen pendientes; véase [Formatos CTRM/PTRM](FORMATOS_CTRM_PTRM.md).

**Guardar plantilla de vista** crea una plantilla reutilizable. Al sobrescribir una plantilla se actualizan las vistas abiertas vinculadas a ella. Elegir **Ninguna** desvincula la vista conservando sus ajustes. Las plantillas mantienen el nombre, título y posición de cámara propios de cada vista; se guardan en `%APPDATA%\TRAMA\PlantillasVistas`.

## Propiedades de elementos

Se muestran los datos que realmente corresponden a los tipos seleccionados: identificación, nombre, comentarios, marca, visibilidad, colores, grosores, material, transparencia, clasificación y medidas geométricas. Las medidas calculadas son de consulta. Las extrusiones se modifican desde su editor de geometría. El material puede ser compartido por varios elementos; los colores de línea, borde y fondo se editan por separado.

TRAMA ya tiene 20 categorías con herencia y material/color efectivos, composición de planos y llamadas a vistas existentes compatibles. Esa clasificación no transforma un sólido en una familia BIM completa ni acredita paridad con todas las categorías, dependencias o herramientas de Revit.
