# Ejercicio de composición de planos

El acceso abre ahora el ejercicio actualizado de **cinco vistas**, con fondo transparente y colocación confirmada mediante un segundo clic. La secuencia más reciente está en **VER-EJERCICIO.html** y en **Interaccion-transparente/LEEME.md**. Abajo se conserva también el registro del ejercicio inicial de tres vistas.

Abre **Ver ejercicio de planos** en el escritorio. Espera a que aparezca la hoja A001; al iniciar se preparan las vistas de origen.

El ejercicio usa el modelo de demostración de Cobra, con dos sólidos. El archivo `.tramaplanos` guarda la composición y las propiedades de sus vistas; no contiene la geometría del modelo.

## Repetir la colocación

1. En el navegador, pulsa con el botón derecho en **Planos** y elige **Nuevo plano**.
2. Escribe un nombre y acepta.
3. Arrastra **3D 1** desde el navegador hasta el papel y suelta el botón. Mueve el recuadro sin mantener pulsado el botón y haz clic para confirmar la posición. Escape cancela.
4. Arrastra **Alzado 1** a otra zona de la misma hoja y confirma su posición con un clic posterior.
5. Arrastra **Tabla 1** a la parte inferior y confirma del mismo modo.
6. Pulsa sobre una vista colocada para seleccionarla. Sus propiedades aparecen a la izquierda.
7. Arrastra su interior para mover el marco completo. Arrastra la línea del título para mover solo el rótulo.
8. En **INICIO**, pulsa **Guardar planos** y elige una copia con otro nombre.

La escala pertenece a la vista de origen: un metro del modelo ocupa 10 mm de papel a 1:100 y 20 mm a 1:50. El zoom de la hoja solo acerca o aleja el papel en pantalla.

Para volver a editar una vista desde la hoja, haz doble clic dentro de su marco. Haz doble clic fuera para volver a componer el plano.

## Lo que se hizo en este ejercicio

Se añadieron **3D 1**, **Alzado 1** y **Tabla 1** arrastrándolos desde el navegador. Se ajustaron los marcos del archivo de ejemplo para separarlos sobre la hoja A1. Después, dentro de Cobra, se hicieron estos movimientos con el ratón y se guardaron desde **INICIO > Guardar planos**:

| Paso | Acción | Resultado |
|---|---|---|
| 1 | Seleccionar la vista 3D | Aparece su marco azul. |
| 2 | Arrastrarla 30 píxeles a la derecha y 20 hacia arriba | Solo se desplazan esa vista y su título. |
| 3 | Arrastrar la segunda vista 20 píxeles a la derecha y 70 hacia abajo | La primera vista mantiene su posición. |
| 4 | Arrastrar la línea del primer título 15 píxeles a la derecha y 17 hacia abajo | El modelo permanece en su posición. |
| 5 | Abrir Alzado 1 y pulsar la cara FRONTAL del cubo | El alzado cambia de orientación y se actualiza en la hoja; la vista 3D conserva la suya. |

Los píxeles describen los movimientos de esta prueba en este monitor. Cobra guarda las posiciones del plano en milímetros.

Las capturas originales de esos pasos están en esta misma carpeta:

- `01-antes-de-mover.jpg`
- `02-primera-vista-movida.jpg`
- `03-segunda-vista-movida.jpg`
- `04-titulo-movido.jpg`
- `05-composicion-guardada.jpg`

Para leer la tabla y los rótulos con más detalle, acerca el papel con la rueda del ratón. Esto no cambia la escala de las vistas.
