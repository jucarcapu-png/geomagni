# Planos en TRAMA

<!-- VIGENCIA_DOC23_20261018 -->
**Corte de referencia: 18/10/2026, candidata 1.5.395; entrega activa 1.5.242.** La candidata no sustituye la instalación activa. Los cambios nuevos requieren su propia compilación y pruebas. Los [26 pendientes y sus criterios](AVANCE_26_PENDIENTES.md) son la lista de continuidad; esta revisión de guías corresponde al n.º 23 y no cierra los otros requisitos.

Una vista colocada lleva rombo morado en su fila del catálogo. Sin colocaciones no aparece indicador ni se reserva espacio; los logos principales se conservan. La retirada manual parcial/última y su reapertura siguen en el pendiente 16. Las plantas nuevas toman el nombre del nivel; los ejercicios antiguos conservan sus nombres.
<!-- FIN_VIGENCIA_DOC23_20261018 -->

Una hoja contiene vistas vinculadas al modelo. Cada vista conserva su cámara, escala, detalle, visibilidad y filtros; la colocación en el plano tiene su propia posición, marco y título.

## Crear y componer

1. En **INICIO → Nuevo plano**, indica el nombre. También puedes utilizar el menú contextual de **Planos** en el navegador.
2. En Propiedades define número, nombre, formato A0–A4, orientación, autor, fecha y descripción. Puedes indicar dimensiones personalizadas en milímetros.
3. Arrastra una vista del navegador al papel. Su icono acompaña al puntero. Al soltar aparece únicamente el recuadro del contenido: muévelo sin mantener pulsado el botón y haz un clic para confirmar. Escape o botón derecho cancelan. También puedes soltarla sobre el nombre de un plano en el navegador y escoger después la posición en la hoja.
4. Las vistas colocadas aparecen como hijos del plano. Un doble clic sobre un hijo abre su hoja y selecciona la colocación.

## Seleccionar y editar

- Un clic en el fondo muestra las propiedades de la hoja.
- Al pasar el puntero sobre una vista se resalta el contorno de su contenido; al salir se apaga. Un clic en una vista selecciona su marco y muestra las propiedades de la vista de origen y de su colocación.
- Arrastra el contenido para moverlo: un recuadro muestra el destino y la posición se confirma al soltar. Escape cancela el movimiento. Las flechas lo desplazan un milímetro; Mayús más flecha, diez milímetros.
- Arrastra el título para cambiar su posición sin mover el dibujo. El control al final de la línea permite ajustar su longitud.
- En Propiedades puedes cambiar el número de detalle, título, posición, tamaño del marco, rotación y bloqueo. Un título vacío hereda el título en plano o el nombre de la vista de origen.
- El tamaño del marco recorta la presentación; la escala de la vista controla el tamaño físico del dibujo.
- Un doble clic dentro de la vista la activa en el plano; el resto de la hoja queda atenuado. Las propiedades corresponden a la vista activada o a los elementos seleccionados en ella.
- Un doble clic fuera, **Desactivar vista** o Escape devuelve el control al plano.
- Supr elimina la colocación seleccionada y mantiene disponible la vista de origen. Una colocación bloqueada no se mueve ni se elimina con los gestos normales.
- La rueda amplía el papel y el botón central permite desplazarlo. Inicio recupera el encuadre de la hoja.

El fondo vacío de cada vista es transparente sobre el papel y sobre las otras vistas. Las caras blancas de los sólidos conservan su opacidad. El recuadro de selección se ajusta al contenido visible y respeta el recorte guardado. Las ventanas de plano utilizan el mismo gestor de fichas, grupos y ventanas flotantes que las vistas.

Las tablas y tablas gráficas muestran datos de los sólidos del modelo según los filtros de la vista. Las leyendas presentan un resumen por modelo. En las vistas documentales, la rueda recorre las filas; los gestos de selección de sólidos quedan desactivados.

## Guardar y reabrir

**Guardar planos** crea un archivo `.tramaplanos` (también lee los anteriores `.cobraplanos`) con las hojas, referencias a vistas, configuraciones, posiciones y títulos. Al cerrar una pestaña, la definición sigue disponible en el navegador durante la sesión.

El archivo de composición **no contiene la geometría del modelo**. Cuando se abre en otra sesión, TRAMA solicita confirmar el vínculo con el modelo actual. Debe abrirse o reconstruirse el modelo correspondiente antes de vincular sus planos. El proyecto tradicional `.tramaproyecto` transporta las formas y catálogos soportados además de los planos; su apertura es aditiva y no recupera todo el espacio de trabajo. El documento autocontenido `.ptrm` y el layout independiente continúan en los pendientes 1–7. Esta guía de composición no acredita impresión/PDF ni un diseñador libre de cajetines.

El cajetín incorporado utiliza el número, nombre, autor, fecha y descripción del plano. Esta implementación reproduce el flujo de composición solicitado; no interpreta archivos de Revit ni sus familias de cajetines.

## Ejercicio visible

El instalador añade **Ver ejercicio de planos** al escritorio. Este acceso carga `Ejemplos/Plano-Ejercicio/Ejercicio-cinco-vistas-transparentes.cobraplanos` con el modelo de demostración. En esa carpeta están la guía `COMO-REPETIR.md`, la secuencia visual `VER-EJERCICIO.html` y las capturas reales de selección, movimiento independiente de dos vistas, movimiento de un título y guardado.

Una secuencia histórica está en `Ejemplos/Plano-Ejercicio/Interaccion-transparente/LEEME.md`: incluye la colocación y el movimiento reales de las vistas Estructural 1 y Seccion 1 sobre la hoja, además de las tres vistas originales.
