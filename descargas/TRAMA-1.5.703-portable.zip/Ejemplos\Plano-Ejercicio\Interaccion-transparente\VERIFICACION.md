# Verificación de la entrega — 26 de septiembre de 2026

Nota (07/10/2026): desde TRAMA 1.5.87 los ejemplos usan la extensión .tramaplanos; este registro conserva los nombres de su fecha y TRAMA sigue abriendo los .cobraplanos.


Compilación: **planos_agrupacion_final**, generada correctamente con las 125 fuentes VB6 verificadas y el manifiesto integrado.

- **Planos:** 27 comprobaciones principales y 28 de dibujo e interacción; cero fallos. Registro iniciado a las 09:25.
- **Gestor de ventanas:** 64 comprobaciones; cero fallos. Incluye agrupación, separación, carga de dieciséis vistas, divisores, cierre de pestañas y paneles.
- **Repintado del plano:** media de 16,0 ms en este computador con el motor compatible y las imágenes de las vistas ya preparadas. No es una garantía de rendimiento para otros equipos o modelos.
- **Transparencia:** se comprobó tanto el fondo vacío transparente como la conservación de caras blancas opacas.
- **Escala:** la prueba confirma que 1:50 produce el doble de tamaño físico en papel que 1:100.
- **Ejercicio visual:** cinco vistas guardadas; se añadieron Estructural 1 y Seccion 1 con el ratón, se movió Estructural 1, se canceló una colocación y se comprobó el resaltado sin selección, Escape desde el anfitrión y la ventana flotante.

Los registros completos están en `_ARCHIVOS_AUXILIARES/Registros` de la copia de trabajo del proyecto. La composición es `Ejercicio-cinco-vistas-transparentes.cobraplanos`; las capturas son las imágenes de esta carpeta.
