# Juego de cursores

Para cambiar el aspecto de un cursor **no hay que tocar código**: basta con
dejar aquí un archivo con el nombre que le corresponde. El programa lo carga de
disco al usarlo, así que se puede rediseñar el juego entero por separado.

## Juego actual: porcelana mate (J)

Elegido por el usuario el 29/10/2026 entre las propuestas que dejó Codex
(`Documents\TRAMA_PropuestaIconos_20261029`, lámina J). Volumen blanco mate,
cantos en tinta `#2A2037` y acentos naranja `#FF7400`. Cinco cursores:
Seleccionar, Órbita, Encuadre, Zoom y Paseo.

## Formato

- Archivos `.cur` de Windows.
- **32 × 32** píxeles, 32 bits con canal alfa.
- El **punto caliente** va dentro del propio archivo; es el píxel que el
  programa considera «la punta» del cursor.
- La vista 3D tiene fondos claros y oscuros: el juego J lleva un borde tenue de
  tinta alrededor de la silueta para no perderse sobre el blanco.

## Nombres que espera el programa

El orden importa: es el número de cursor que usa `Mostrar_Cursor`.

| Nº | Archivo | Para qué | Punto activo |
|---|---|---|---|
| 1 | `Cursor_Amplia.cur` | Zoom: región y Ctrl + botón central (lupa J) | centro del cristal (12, 12) |
| 2 | `Cursor_Dibuja.cur` | Comandos de dibujo | — |
| 3 | `Cursor_Move.cur` | Mover caja de sección y región de recorte | — |
| 4 | `Cursor_Move_Horizontal.cur` | Desplazar en horizontal | — |
| 5 | `Cursor_Move_Vertical.cur` | Desplazar en vertical | — |
| 6 | `Cursor_Rotate.cur` | Órbita: Shift + botón central y ViewCube (esfera J) | centro (16, 16) |
| 7 | `Cursor_Agarra.cur` | Encuadre: pan con el botón central (mano J) | centro (16, 16) |
| 8 | `Cursor_Mas.cur` | Sumar a la selección (Ctrl) | — |
| 9 | `Cursor_Menos.cur` | Restar de la selección (Mayúsculas) | — |
| 10 | `Cursor_Arcos_Medio.cur` | Arco por punto medio | — |
| 11 | `Cursor_Arcos_Extremos.cur` | Arco por extremos | — |
| 12 | `Cursor_Seleccion.cur` | Flecha normal de la vista (flecha J) | punta (1, 1) |
| 13 | `Cursor_Paseo.cur` | Paseo de la rueda de navegación (huellas J) | centro (16, 16) |

La lista vive en `Cls_Mundo3D.Cargar_Cursores_Disponibles`. Añadir un cursor
nuevo sí pide tocar esa rutina; **sustituir** uno existente, no.

Mientras dura un gesto de navegación (pan, órbita o zoom con el botón central,
paseo de la rueda) `FrmTrabajo.Cursor_Gesto_Navegacion` fija su cursor, aunque
el dibujado de cada cuadro pida la flecha.

## Si falta un archivo

No pasa nada: `Mostrar_Cursor` lo detecta y usa la cruz del sistema; si falta
`Cursor_Seleccion.cur`, queda la flecha de Windows.

## Regenerar el juego J

`_ARCHIVOS_AUXILIARES\Herramientas\CursoresJ`:

1. `recortar_j.ps1 -Img J_porcelana_mate.png -Salida <carpeta>` separa los cinco
   símbolos de la lámina sin fondo ni sombra proyectada.
2. `componer_cur.ps1 -Origen <carpeta> -Salida <carpeta>\cur` los reduce a 32 px,
   añade el borde y escribe cada `.cur` con su punto activo.
3. `lamina.ps1` dibuja la muestra sobre fondo claro y oscuro
   (`MUESTRA_CURSORES_32.png`).

El cursor de la lupa anterior se generaba con `GenerarCursorLupa.py`; los
originales están en `Respaldos\CursoresJ_20261029\Antes`.
