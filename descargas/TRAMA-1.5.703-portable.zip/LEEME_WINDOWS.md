# TRAMA para Windows

<!-- VIGENCIA_DOC23_20261018 -->
**Estado de desarrollo al 18/10/2026.** La última candidata de referencia es **1.5.400**, recuperada en _ARCHIVOS_AUXILIARES/Respaldos/Recuperaciones/Pendientes400. La entrega activa permanece en **1.5.242**; la candidata no se ha instalado ni fusionado por pasar sus bancos. Se trabaja siempre en la carpeta principal de **C:**; D: es respaldo.

La continuación tiene [26 pendientes numerados](_ARCHIVOS_AUXILIARES/Documentos/Guias/AVANCE_26_PENDIENTES.md). Esta guía describe la base validada400, no anuncia como terminados los formatos completos CTRM/PTRM, las familias anidadas ni el aislamiento multiproyecto. Sus fundamentos ZIP e iconos no equivalen a esos flujos. Para editar se usa el acceso de VB6 descrito abajo: F5 abre la compilación externa comprobada, no depura las nuevas ediciones.
<!-- FIN_VIGENCIA_DOC23_20261018 -->

TRAMA, una plataforma de GEOMAGNI: plataforma BIM y gestión integral de proyectos. © 2026 GEOMAGNI TECNOLOGÍAS S.A.S.

Antes se llamaba Cobra Akira. Desde la entrega 1.5.88 los nombres internos también son TRAMA: `TRAMA.exe`, `IniciarTRAMA.exe`, `TramaGL.dll`, la carpeta `%LOCALAPPDATA%\Programs\TRAMA` y las extensiones `.tramaplanos`, `.tramareferencias`, `.tramavista`, `.tramarecorrido`, `.tramacamara` y `.tramaconfiguracion`. Los archivos `.cobra*` creados con versiones anteriores siguen abriéndose y, si se vuelven a guardar en el mismo archivo, conservan su nombre; los archivos nuevos usan `.trama*`.

## Instalar y abrir

1. Copie **Instalar-TRAMA.exe** al computador de destino.
2. Ejecútelo con doble clic. Instala para el usuario actual, crea accesos en el escritorio y en Inicio (carpeta **TRAMA**), y abre TRAMA.
3. Use el acceso **TRAMA**. La primera apertura comprueba el dibujo y puede tardar cerca de un minuto.

Al actualizar desde una versión anterior (Cobra Akira o TRAMA hasta 1.5.80), el instalador traslada completa la instalación anterior, `%LOCALAPPDATA%\Programs\CobraAkira`, a `Respaldos\<fecha>\InstalacionAnterior_CobraAkira` dentro de la nueva. Los accesos antiguos («Cobra Akira», «Ver ejercicio de planos» y «Ver ejercicio de recorridos») pasan a `Respaldos\<fecha>\AccesosAnteriores`, solo si apuntan a ese mismo programa, y se crean **TRAMA**, **TRAMA - Ejercicio de planos** y **TRAMA - Ejercicio de recorridos**.

El primer inicio copia a TRAMA los datos del usuario guardados con el nombre anterior: plantillas y unidades de `%APPDATA%\CobraAkira`, la selección gráfica ya comprobada y los ajustes del registro. No reemplaza nada que ya exista ni borra los originales, y deja constancia en `%APPDATA%\TRAMA\MigracionCobraAkira.txt`.

No necesita instalar Visual Basic, registrar controles, descargar componentes ni tener permisos de administrador. El instalador contiene todos los archivos específicos del programa. Usa los componentes de Windows y .NET Framework 4.x incluidos en Windows 10/11.

Instalación: `%LOCALAPPDATA%\Programs\TRAMA`. Al actualizar, conserva una copia de los archivos sustituidos en `Respaldos`. Los registros y archivos que haya creado el usuario no se incluyen en el paquete ni se borran.

## Versión portátil

Extraiga **TRAMA-Windows-Portable.zip** completo en una carpeta donde pueda escribir y abra **IniciarTRAMA.exe**. No ejecute desde la ventana del ZIP. Conserve todos los archivos y subcarpetas juntos. El ejecutable `TRAMA.exe` de la raíz también abre el selector automático.

## Abrir el proyecto de desarrollo en VB6

El proyecto editable sigue siendo `CobraAkira.vbp` de la carpeta principal. Para abrirlo con las dependencias de su compilación, use el acceso **Abrir proyecto TRAMA en VB6**, dentro de `_ARCHIVOS_AUXILIARES/Herramientas`. No trabaje sobre los fuentes de una recuperación.

El acceso ejecuta `AbrirProyectoVB6.ps1`. Comprueba que el VBP y el entorno de `_ARCHIVOS_AUXILIARES/Registros/entorno_vb6.json` correspondan a la misma versión registrada, y valida los ejecutables, manifiestos, biblioteca nativa, servicio de documentos y dependencias del motor compatible. Rechaza una entrega antigua o modificada. Si Windows solicita permiso para VB6, debe responder el usuario.

**F5 conserva el arranque externo actual:** abre la compilación verificada a través de su iniciador de OpenGL. No ejecuta los cambios nuevos ni los puntos de interrupción de los fuentes. Para ver cambios de código hay que compilar con `Compilar.ps1`, recuperar y probar esa nueva versión y actualizar el entorno de desarrollo; nunca recompilar manualmente sobre un número ya usado. Este acceso no instala ni sustituye la entrega activa.

## Selección gráfica automática

El programa comprueba su propia escena 3D en un proceso separado. Si la tarjeta gráfica no presenta correctamente la imagen, prueba el motor Mesa/LLVMpipe incluido y lo activa automáticamente. El modo compatible usa el procesador y puede ser más lento con escenas grandes. Se identifica en el título.

La selección comprobada se conserva para este usuario y esta instalación de Windows, sin vencimiento por días y sin repetir la prueba al actualizar o cambiar de carpeta el programa. Se vuelve a comprobar si cambia Windows, el controlador gráfico o el uso de escritorio remoto. Un controlador reparado sin cambiar de versión puede volver a probarse con `IniciarTRAMA.exe /diagnostico`.

Diagnósticos del arranque: `%LOCALAPPDATA%\TRAMA\Registros`. Diagnósticos de la aplicación: `_ARCHIVOS_AUXILIARES\Registros` dentro de la carpeta instalada.

## Tamaño de la interfaz y textos 3D

Al iniciar, TRAMA consulta el área útil y la escala de Windows. En pantallas con poco espacio aplica una densidad compacta a la portada, cinta, iconos, títulos de herramientas y controles inferiores. El cubo en modo Automático también cambia con el tamaño de la vista. No cambia la resolución ni la configuración de pantalla de Windows.

La identidad conserva TRAMA y el símbolo GEOMAGNI A2 de dos ranuras, con firma tipográfica Sora/Inter. La portada combina navy #14263B e isla blanca. Las cabeceras de herramientas usan azules por foco y sus pies son claros. La barra de título usa morado #5B2A86 (Windows 11); foco y anclaje conservan acento naranja #FF7400. Fichas inactivas, franja libre y desplegable usan gris RGB(224,224,224), con ficha activa blanca. **Gestionar → Ayuda → Acerca de TRAMA** muestra la versión y el titular.

La interfaz usa la tipografía de la marca: Inter en los textos y Sora en los títulos. Las fuentes van en `Recursos\Fuentes` (licencia SIL OFL 1.1, en `Licencias`) y se cargan solo para TRAMA, sin instalarlas en Windows. Si faltan, la interfaz usa Segoe UI.

La cinta incluye **Archivo**, con fondo corporativo morado, y las fichas Crear, Inicio, Vista y Gestionar. Las fichas contextuales aparecen solo cuando hay algo que tratar, como en Revit: **Modificar | …** con un sólido seleccionado o un contorno en edición, y **Modificar | Recorrido** al editar o activar un recorrido.

El manifiesto está integrado en ambos ejecutables de TRAMA y también se entrega como archivo `.exe.manifest`. Declara conciencia de DPI del sistema. No se declara PerMonitorV2: los controles VB6 necesitan más cambios para ajustar todos sus tamaños en vivo al arrastrar entre monitores con escalas diferentes. Tras cambiar la escala de Windows, cierre y vuelva a abrir TRAMA; la combinación de monitores con distintos DPI sigue pendiente de validación.

Si el motor OpenGL no construye las fuentes de Windows, TRAMA genera automáticamente los contornos de las letras con GDI y GLU. Incluye texto relleno, contornos, espacios y caracteres de la página ANSI de Windows, como ñ y tildes. El diagnóstico de arranque exige que estén creadas las cinco fuentes de la vista.

Opciones de soporte:

- `/diagnostico`: vuelve a comprobar ambos motores según sea necesario, guarda el resultado y termina.
- `/software`: comprueba y usa el motor compatible.
- `/hardware`: comprueba exclusivamente el controlador del equipo; informa si falla.
- `/software /sin_vbo /prueba_render`: comprueba el dibujo clásico sin VBO.
- `/software /autotest`: ejecuta el banco existente del gestor de ventanas.

## Alcance comprobado

Preparado para Windows 10 y 11 de escritorio con ejecución de aplicaciones x86. Validado localmente en Windows 11 de 64 bits con AMD Radeon Vega 8, tanto con selección automática como con Mesa y con el dibujo clásico sin VBO. No se ha certificado en otros computadores, Intel/NVIDIA, Windows ARM, escritorios remotos ni Windows anteriores. No es posible garantizar literalmente todas las versiones y configuraciones de Windows sin probarlas.

No modifica los controladores gráficos ni copia archivos a las carpetas de Windows.

## Propiedades de vistas y elementos

La paleta sigue la vista activa o los elementos seleccionados. Incluye escala y detalle sincronizados con la barra inferior, modificaciones por categoría, opciones gráficas, cámara, recortes, fases, alternativas, piezas y edición de propiedades comunes en selección múltiple. Consulte [la guía de propiedades](_ARCHIVOS_AUXILIARES/Documentos/Guias/PROPIEDADES_DE_VISTA.md) para el uso, los archivos de configuración y el alcance de estas herramientas.

Las configuraciones `.tramavista` (y las antiguas `.cobravista`) guardan propiedades de una vista; no guardan la geometría del proyecto. Las plantillas reutilizables se guardan por usuario, como `.tramaplantilla`, en `%APPDATA%\TRAMA\PlantillasVistas`.

## Para desarrollar

Las fuentes VB6 son Windows-1252 con CRLF. `Nativo\Referencias\vbogl.tlb` es la referencia de compilación local. El computador de desarrollo necesita VB6 y sus controles de diseño instalados.

Compile con `_ARCHIVOS_AUXILIARES\Herramientas\Compilar.ps1`; también recompila el puente nativo usando Visual C++ 6. Prepare los binarios de arranque y respaldo con `Empaquetar.ps1 -SoloPreparar`; genere la entrega completa con `Empaquetar.ps1`. `PruebaFuentes.ps1` valida las letras rellenas, los huecos y el dibujo de contornos sobre Mesa. La distribución de ejecución no requiere el IDE, Python ni estas herramientas.

Componentes y procedencia: carpeta `Licencias`.

## Organizar vistas, planos y recorridos

Cuando no caben todas las fichas, las restantes se eligen desde el desplegable derecho; no deben invadir el navegador ni mostrar flechas nativas. Cada grupo conserva su ancho. El caso de siete vistas, dos grupos, flotación individual y reagrupación se observó en 395. Otras escalas y la continuidad durante todo el gesto siguen pendientes.

Un clic activa una vista. Para separarla, arrastre su pestaña fuera de la barra: solo se desprende esa vista y las demás permanecen en su grupo. Una vez flotante, muévala desde el título.

Para volver a agruparla, lleve el puntero a la barra de pestañas del grupo de destino. Para dividir el espacio, acérquelo al borde izquierdo, derecho, inferior o a la zona justo debajo de las pestañas. El sombreado muestra el espacio de destino; suelte cuando corresponda con la posición deseada. Escape cancela la reubicación pendiente.

El cambio de la banda del recorrido espera a que termine el gesto para no desplazar la pestaña bajo el puntero. Las cámaras, trayectorias y contenido de los planos conservan sus valores al reorganizar las ventanas.

Después de modificar el gestor o incorporar un nuevo tipo de vista, ejecute `_ARCHIVOS_AUXILIARES\Herramientas\ValidarInterfaz.ps1` y repita una comprobación visible de clic, arrastre, cuatro lados, agrupación y cancelación. El banco con documentos usa vistas 3D, planos y recorridos reales.


## Niveles, ejes y vistas del proyecto

El navegador agrupa el proyecto en Vistas, Leyendas, Tablas, Planos, Familias, Grupos y Vínculos. Sólo estas ramas principales llevan icono; las categorías interiores y las vistas conservan las ramificaciones punteadas. Los signos +/− aparecen cuando hay hijos.

En **Crear → Niveles y ejes** puede añadir niveles por nombre y elevación en metros. Para dibujarlos con dos puntos, active un alzado o una sección y pulse **Nivel**. **Eje** coloca una referencia recta con dos puntos. Pase el puntero para resaltarla, haga clic para seleccionarla y use sus agarres o la paleta Propiedades para editar extremos, cota, símbolos y bloqueo.

En **VISTA → Crear vistas**:

- **Planta** y **Cielo raso** permiten seleccionar varios niveles. El proyecto inicial registra plantas **NIVEL 1, NIVEL 2…** asociadas a sus niveles; se conservan nombres antiguos o personalizados. La opción No duplicar excluye los niveles con ese tipo de vista; desmárquela para crear copias. Las plantas estructurales tendrán su disciplina propia en una fase posterior.
- **Sección** usa dos puntos para definir el corte; sus extremos, ancho, profundidad y dirección se pueden modificar después.
- **Alzado** usa un punto de cámara y otro para orientar la mirada. La banda permite escoger nivel, desfase, escala y creación de cuatro direcciones.
- **Llamada / detalle** usa dos esquinas para crear una vista delimitada, asociada a su origen. También se puede crear una copia independiente.

Durante la colocación, la banda contextual permite cambiar nivel, desfase, escala y apertura inmediata de la vista. **Finalizar** conserva lo creado y termina la herramienta; **Cancelar** abandona la colocación pendiente. Deshacer/rehacer recupera creación, cambios y eliminación de referencias. Si una referencia tiene vistas dependientes, la eliminación informa de ellas; las vistas colocadas en planos deben retirarse antes de eliminarlas.

El cielo raso se presenta como techo reflejado: conserva la misma orientación de la planta. Esa orientación se mantiene en las llamadas, copias, selecciones y vistas colocadas en planos.

Las rejillas se leen de frente en planta, cielo raso y alzado. En 3D se representan en la cota del nivel más bajo del catálogo; los niveles se muestran a su propia elevación. Los nombres y símbolos conservan el plano de la referencia al girar la cámara. El cambio de representación no altera los extremos guardados de los ejes.

Cada vista conserva su cámara, escala, recorte y propiedades. Sin elementos seleccionados, Propiedades corresponde a la vista; al seleccionar una referencia, muestra sus valores. Renombrar una vista actualiza su pestaña y el navegador. Cambiar la cota de un nivel mueve las definiciones y cámaras de sus vistas asociadas conservando su encuadre relativo. Los sólidos no se desplazan automáticamente con el nivel.

Las referencias incorporan extensiones 2D por vista sin cambiar el datum compartido. El plano de nivel 3D admite extensión manual con cuatro agarres. Las llamadas pueden referenciar una vista existente compatible sin duplicarla. Los cortes consideran categoría BIM y material efectivo; esto no crea un sistema completo de muros por capas. Permanecen ejes rectos, burbujas globales, oclusión conservadora de rótulos y llamadas sin destino 3D/recorrido.

El plano seleccionado del nivel 3D ocupa su cota real: el sólido delante oculta su relleno y, donde el plano está delante, se ve su transparencia. El sólido permanece completo. El cubo Automático es compacto y su botón de restauración se omite en las vistas 2D de proyecto.

**INICIO → Guardar referencias** conserva el catálogo en `.tramareferencias` (abre también `.cobrareferencias`): niveles, ejes, definiciones, escalas, perfiles y cámaras. No contiene geometría ni planos. **Abrir referencias** lo incorpora sobre el modelo actual, validando nombres, tipos y relaciones antes de aplicar cambios. Los planos `.tramaplanos` conservan también la definición y el nivel de cada vista colocada y siguen admitiendo los archivos antiguos. Para trasladar todo el catálogo, abra primero las referencias y luego los planos sobre la misma geometría. Los archivos sustituidos se respaldan en `_ARCHIVOS_AUXILIARES/Respaldos/ArchivosGuardados`.

Las nuevas vistas admiten pestañas, flotación, agrupación y anclaje individual a los cuatro lados. Se colocan en planos arrastrándolas desde el navegador y confirmando la posición con el segundo clic; su escala determina el tamaño en el papel.

## Unidades de proyecto

**Gestionar → Unidades de proyecto** sigue el cuadro de Revit 2019: disciplina Común y Estructura, agrupación de dígitos, símbolo decimal y, para cada tipo, unidad, redondeo, símbolo y supresión de ceros. Los valores se guardan internamente en unidades SI y cambiar el formato no altera la geometría. Cotas, ángulos, propiedades de vistas, niveles, recorridos, planos y materiales se muestran y editan en el formato del proyecto; se puede escribir un valor con o sin unidad (por ejemplo `2,5 m` o `2500 mm`). Un campo que no se toca conserva su valor exacto aunque la pantalla lo redondee.

**Configuración adicional** ya incluye edición y persistencia de catálogos con conservación de identidades y validación. Patrones presenta primero los 27 nombres en el orden observado en el proyecto de Revit; las 74 definiciones observadas conservan procedencia y traducción. Variantes y patrones nuevos del usuario siguen disponibles. No es un catálogo universal de todas las versiones de Revit.

Los rellenos de **Configuración adicional** disponen de los modos observados en Revit. En el modo **Simple** se indican el ángulo de línea y el interlineado, con líneas paralelas o rayado cruzado. Los de modelo usan las unidades del proyecto y los de croquis, mm de papel. Los patrones con origen, desfase o tramos se editan como **Personalizado**, con el texto de familias.

## Renderizado

**Vista → Presentación → Renderizar** abre el cuadro de renderizado de la vista 3D activa (no se renderizan plantas, alzados, secciones ni planos):

- **Calidad:** Borrador, Media, Alta, Óptima o un ajuste personalizado. **Editar…** permite fijar la precisión de luz y materiales y la duración: por nivel, por tiempo o hasta que sea satisfactoria.
- **Salida:** resolución de pantalla o de impresora (75 a 600 PPP), con el tamaño resultante en píxeles.
- **Iluminación:** esquemas exteriores o interiores con sol, luces artificiales o ambos. El sol es el del estudio solar; si no hay, se ilumina como «En sesión, iluminación», relativo a la vista.
- **Fondo:** cielo de cinco nubosidades, color, imagen o transparente, con neblina. La imagen de fondo se ajusta a la vista sin deformarse.
- **Imagen:** ajustar exposición, guardar en el proyecto o exportar.

**Región** (disponible cuando ya hay una imagen) permite arrastrar un rectángulo sobre la vista previa. Al renderizar solo se recalcula ese rectángulo y el resto se conserva.

**Renderizar** calcula sombras, interreflexión de color, vidrio con refracción, reflejos y un suelo bajo el modelo en los exteriores. La imagen se refina en la vista previa mientras se calcula y al terminar se elimina el ruido. **Cancelar** detiene el cálculo.

**Ajustar exposición…** cambia valor de exposición, resaltes, sombras, saturación y punto blanco sin renderizar de nuevo; **Aplicar** muestra el cambio sin cerrar el cuadro. **Exportar…** guarda BMP, JPG o PNG; PNG conserva el fondo transparente.

**Guardar en proyecto…** crea una vista en el navegador, categoría Renderizado. Esa vista se abre como las demás, se exporta y se coloca en planos arrastrándola desde el navegador; en el papel ocupa sus píxeles a la resolución de salida. Al guardar los planos, el archivo `.tramaplanos` incluye la imagen de cada renderización colocada y la recupera al abrirlo.

Cada vista conserva su propia configuración de renderización, editable también desde la paleta Propiedades (**Configuración de renderización → Editar…**). Si una vista 3D con configuración propia está colocada en un plano, el `.tramaplanos` guarda esa configuración y la devuelve a la vista al abrirlo. Una vista con la configuración de defecto no añade nada al archivo, que sigue abriéndose en versiones anteriores.

El formato tradicional **.tramaproyecto** conserva el catálogo de renderizaciones aunque no estén colocadas y las vistas 3D con sus perfiles y configuración de render. Las imágenes se guardan en PNG sin pérdida con sus PPP; se siguen leyendo JPEG antiguos. Abrir ese proyecto es una importación aditiva: no recupera todo el layout ni aísla proyectos independientes. Los nuevos **.ptrm/.ctrm** completos siguen en desarrollo según [su contrato](_ARCHIVOS_AUXILIARES/Documentos/Guias/FORMATOS_CTRM_PTRM.md).

La vista interactiva ya dispone de oclusión ambiental, sombras de contacto y penumbra optativas en GPU, limitadas a la profundidad visible. El render final continúa en CPU; no se ha convertido en render GPU. El fondo fotográfico es composición y no ilumina la escena. El cotejo completo con Revit, el coste en modelos reales y otras escalas siguen pendientes; no se deducen FPS de los bancos.

Si el motor elegido es Mesa/llvmpipe, esa ruta se ejecuta por software; sus resultados no acreditan trabajo de la tarjeta gráfica física.

## Organización del proyecto

Las guías están en `_ARCHIVOS_AUXILIARES/Documentos/Guias`. Todos los respaldos y versiones se guardan en `_ARCHIVOS_AUXILIARES/Respaldos`. La bitácora se conserva en `_ARCHIVOS_AUXILIARES/BITACORA_INTEGRACION_COBRA_AKIRA.md`. Consultar [la organización](_ARCHIVOS_AUXILIARES/Documentos/ORGANIZACION.md) antes de modificar la estructura.
