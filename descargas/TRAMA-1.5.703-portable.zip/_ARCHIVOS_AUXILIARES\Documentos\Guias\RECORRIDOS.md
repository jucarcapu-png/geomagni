﻿# Recorridos de cámara

<!-- VIGENCIA_DOC23_20261018 -->
**Corte de referencia: 18/10/2026, candidata 1.5.395; entrega activa 1.5.242.** La candidata no sustituye la instalación activa. Los cambios nuevos requieren su propia compilación y pruebas. Los [26 pendientes y sus criterios](AVANCE_26_PENDIENTES.md) son la lista de continuidad; esta revisión de guías corresponde al n.º 23 y no cierra los otros requisitos.

Spline, banda contextual, cámaras, fotogramas y AVI/BMP ya están implementados. La cámara azul y su vista se sincronizan sin cambiar el encuadre del observador. La continuidad física y su medición pertenecen al pendiente 9; observar fotogramas distintos no certifica FPS.
<!-- FIN_VIGENCIA_DOC23_20261018 -->

En **VISTA > Recorridos > Recorrido**, abra una vista del modelo y coloque los puntos del camino con clics. TRAMA utiliza la spline cúbica existente del programa; el ojo y el destino se interpolan por ese método.

La banda verde permite elegir **Desde** (nivel) y **Desfase**, expresado en metros. Cambiar estos valores afecta a los siguientes puntos. Puede cambiar de pestaña y continuar colocando puntos desde otra vista del modelo. **Enter / Finalizar** confirma el camino; **Esc / Cancelar** revierte la sesión.

En **Modificar | Recorrido**:

- **Camino**: seleccionar y arrastrar puntos rojos. Mantener **Mayús** al iniciar el arrastre permite moverlos en un plano vertical; en un alzado se usa un plano vertical cuando el horizontal queda de canto.
- **Cámara activa**: seleccionar una clave o un lugar del camino. El punto magenta mueve el destino; los otros controles cambian la apertura y el límite lejano. Para valores precisos use **Cámara**.
- **Añadir / Eliminar fotograma clave**: clic en el camino o en una clave. Deben quedar al menos dos claves.
- **Deshacer / Ctrl+Z** revierte la última edición; **Esc** durante un arrastre lo revierte.
- **Cámara**: coordenadas del ojo y destino, nivel, desfase, dirección, inclinación, giro, campo horizontal, amplitud ortogonal y límites cercano/lejano de cada clave.
- **Fotogramas**: cantidad total (300 por defecto), frecuencia (15 por segundo), velocidad uniforme, acelerador por tramo (0,1–10), indicadores y duración.
- **Abrir recorrido** muestra la cámara; la barra permite ir a un fotograma concreto, incluidos los decimales. **Reproducir** avanza a tiempo real; el mismo botón pausa y **Esc** detiene.

Cada recorrido aparece en **Navegador > Vistas > Recorridos**. Su ventana utiliza el mismo gestor de pestañas y mantiene su cámara separada de las demás vistas.

**Guardar** escribe un archivo `.tramarecorrido` (también lee los antiguos `.cobrarecorrido`) con el camino, sus cámaras y la configuración gráfica. **Abrir recorrido** carga ese archivo sobre el modelo que esté abierto; el archivo no contiene la geometría del modelo. Conserve también el archivo del modelo.

## Vídeo

**Exportar vídeo** permite elegir fotogramas inicial/final, frecuencia, resolución, ampliación, estilo visual y AVI o secuencia BMP. La imagen se genera con las dimensiones escogidas, independientemente del tamaño de la ventana. La vista previa conserva la proporción del vídeo.

El AVI se escribe sin compresión para no depender de códecs adicionales: puede ocupar mucho espacio. El límite de esta modalidad es 1,8 GB por exportación; use menor resolución, menos fotogramas o la secuencia BMP para recorridos más grandes. **Esc** cancela y conserva el archivo de destino anterior. No se incluyen el navegador, el cubo, los puntos de control ni el camino en el vídeo.

## Ejercicio visible

**VISTA > Recorridos > Ejemplo** crea ocho puntos alrededor del modelo, subiendo de altura. Cambie el control a **Camino**, arrastre un punto, use **Deshacer**, abra la cámara y reproduzca. El acceso `Ver ejercicio de recorridos` abre directamente este ejemplo.

Las referencias de comportamiento son las capturas aportadas y la inspección de Revit 2019. La configuración temporal y la exportación se contrastaron con [Fotogramas de recorrido](https://help.autodesk.com/cloudhelp/2021/ENU/Revit-DocumentPresent/files/GUID-FCAD7180-D15D-4097-9D04-BB57A9ADBEE6.htm) y [Exportación](https://help.autodesk.com/cloudhelp/2022/ENU/Revit-DocumentPresent/files/GUID-9BC8682E-BC27-46DA-BB9A-CCB1090352F8.htm).
