# Ejercicio de recorrido

Abra **Ver ejercicio de recorridos** o use **VISTA > Recorridos > Ejemplo**. Se crea una trayectoria de ocho claves alrededor del modelo, con cambio de altura.

1. Seleccione **Camino** en la banda verde y arrastre un punto rojo. La spline y la cámara se actualizan. **Deshacer** recupera la posición.
2. Seleccione **Cámara activa**. Arrastre el destino magenta o abra **Cámara** para escribir sus ángulos, apertura y límites.
3. **Finalizar** abre la vista del recorrido. Pulse **Reproducir**: recorre las 300 imágenes en 20 segundos a 15 fps. La reproducción puede omitir imágenes si el equipo no alcanza esa velocidad; la exportación calcula todas.
4. **Fotogramas** ajusta duración, velocidad y claves. **Exportar vídeo** permite AVI o BMP; **Guardar** conserva la trayectoria.
5. Para trazar otra ruta, abra una vista del modelo, pulse **VISTA > Recorridos > Recorrido**, coloque puntos y cambie **Desde/Desfase [m]** entre puntos. Finalice con Enter.

`Ocho-claves-dos-alturas.tramarecorrido` conserva el ejemplo. No contiene geometría: ábralo con el mismo modelo. `Muestra-ocho-fotogramas.avi` es una muestra corta que cubre el camino completo con ocho imágenes a 640 × 360, generadas por Cobra. No representa la suavidad de la reproducción de 300 imágenes.

La guía completa es [RECORRIDOS.md](../../RECORRIDOS.md).
