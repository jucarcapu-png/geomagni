# Formatos propios CTRM y PTRM de TRAMA

## Estado vigente al 23/10/2026 — F5 1.5.497: PTRM y CTRM completos

- **PTRM de proyecto completo**, perfil `proyecto-trama-1` (`ModProyectoPTRM`).
  - Partes:
    - `proyecto/documento.xml`, el descriptor;
    - `proyecto/proyecto.tramaproyecto`, con sólidos, componentes, referencias, renders, vistas, recorridos, planos y espacio de trabajo;
    - `configuracion/catalogos.xml` y `configuracion/unidades.txt`;
    - `recursos/`, con las texturas y los componentes cargados;
    - `manifest.xml`.
  - Abrir crea un proyecto independiente en la misma ventana.
  - Guardar detecta cambios externos y deja respaldo; Guardar como nunca sobrescribe.
- **CTRM de componente**, perfil `componente-trama-1` (`ModComponenteCTRM`).
  - Partes:
    - `componente/documento.xml`, el descriptor;
    - `componente/componente.tramacomponente`, con sólidos, parámetros con sus fórmulas, tipos, planos de referencia, cotas y ejemplares anidados;
    - `componente/anidados/aN.tramacomponente`;
    - `manifest.xml`.
  - Las rutas de los anidados dentro del paquete se escriben `%CTRM%/componente/...`.
- **Anidados:**
  - líneas `EJEMPLARHIJO id|padre|n1,n2|nombre|archivo|asociaciones|estado` y `EJEMPLARASOC id|asociaciones`;
  - una asociación gobierna un parámetro del hijo con una fórmula del anfitrión.
- **Compatibilidad:** aviso antes de abrir novedades de otra versión. Al guardar se conservan las partes, los atributos y las secciones que TRAMA no interpreta (`Paquete_ConservarDesconocidos`).
- **Validación:** bancos PTP24, CTP31 y PRY38 en la 497 (4088/0 en total). Auditoría `FORMATOS_PTRM_CTRM_497_20261023.md`.
- **Límites:** los materiales del componente se enlazan por nombre; las asociaciones se crean con cuadros de texto; sin comprobación manual en pantalla.

Los bloques siguientes son historia.

## Estado vigente al21/10/2026 — F5 1.5.430

PGC1 ya une captura geométrica real con paquete PTRM y lector semántico CPU para un **perfil interno parcial**. Su ciclo portable editar/GuardarComo/reabrir pasa37criterios propios; Documentos240 también pasa. Total focalizado de430:439/0, con PNL42 y GFX39 en software y AMD. Ver auditoría PAQUETE_GEOMETRICO_Y_PLANO_NIVEL_430_20261021.md. El núcleoCPU de421/412 es antecedente, no resultado nuevo de430.

No están habilitados PTRM/CTRM completos, segundo proyecto visible ni edición gráfica de este perfil. GuardarComo no sustituye Guardar sobre el mismo archivo ni detecta todavía una edición externa desde la apertura. El cierre de estos requisitos conserva su criterio completo. Idioma/tema siguen siendo del usuario.

## Incremento PGC1: paquete geométrico y preparación CPU por propietario

**Implementado y probado en la 1.5.430, con alcance interno parcial.** PGC1 conecta la captura de geometría real del World con el contenedor PTRM y su lector semántico CPU. Es un perfil interno parcial para `GuardarComo`, preparación, edición geométrica y reapertura. No habilita el guardado/apertura de un proyecto completo, familias CTRM, interfaz gráfica ni un segundo PTRM en la ventana actual. No aumentar el porcentaje de pendientes completos por esta propuesta.

### API explícita y propiedad

- `DocGeo_GuardarCaptura(C, Captura, CarpetaNueva, DestinoNuevo, Mensaje)`: recibe un `Cls_ContextoDocumento` y una `Cls_CapturaGeometriaCPU` ya vinculada al mismo dueño, con mapa explícito de modelos. Captura geometría evaluada, configuración y unidades de ese contexto; incorpora sus recursos y crea el paquete validado.
- `DocGeo_PrepararLectura(Ruta, CarpetaNueva, AceptarNovedades, Preparado, Mensaje, Advertencia)`: trabaja sobre una copia propia del archivo original, valida el contenedor y sus partes semánticas y devuelve un `Cls_DocGeomPreparado`. El rechazo deja la salida `Nothing`; no publica un contexto ni aplica datos a las sesiones existentes.
- `DocGeo_GuardarPreparado(Preparado, CarpetaNueva, DestinoNuevo, Mensaje)`: guarda la geometría CPU editada en otro paquete. En este incremento, la configuración y las unidades capturadas se conservan; no se vuelven a serializar desde los valores predeterminados del contexto temporal.

`DocCfg_GuardarContexto` y `DocCfg_LeerContexto` usan exclusivamente `C.Configuracion` y `C.Unidades`. Las APIs antiguas de configuración conservan su comportamiento. PGC1 prepara el catálogo como DTO (`EstadoCatalogos`/`CatalogosXML`); no llama a `CFG_ConfirmarEstado` ni materializa recursos GL. El temporal mantiene sus unidades en un servicio privado. Los consumidores futuros deben usar el DTO preparado hasta completar la transacción de materialización del catálogo; no asumir que `ContextoCPU.Configuracion` ya contiene el catálogo importado.

La clase preparada expone `DocumentoId`, `Nombre`, `ContextoCPU`, `Geometria`, `CatalogosXML`, `UnidadesTexto` y `Advertencia`. `DocumentoId` conserva el GUID persistido del paquete. `ContextoCPU.Id` es un GUID nuevo de staging y permanece fuera del registro de documentos. Esta separación permite preparar datos sin colisionar con un proyecto ya abierto; no constituye autorización para publicar dos proyectos con identidad persistente duplicada.

### Perfil y partes

El paquete usa el manifiesto existente `TramaPackage` con `kind="proyecto"`, `documentId` y `coreSchemaVersion="1"`. El descriptor declara expresamente el alcance parcial:

```xml
<DocumentoTRAMA coreSchemaVersion="1" id="GUID-del-documento"
                type="proyecto" perfil="geometria-facetada-cpu-1"
                nombre="Nombre del proyecto">
  <Nucleo geometria="modelo/geometria.xml"
          catalogos="configuracion/catalogos.xml"
          unidades="configuracion/unidades.txt" />
</DocumentoTRAMA>
```

Partes conocidas: `proyecto/documento.xml`, `modelo/geometria.xml`, `configuracion/catalogos.xml`, `configuracion/unidades.txt` y recursos internos bajo `recursos/`. La geometría usa el núcleo CPU1 ya existente, en metros, con identidades de modelo/sólido/cara, nombres, visibilidad, categoría y parámetros básicos admitidos. Material 0 significa sin asignar; cada material positivo debe existir por su ID local en el catálogo del mismo paquete. No resolverlo contra B ni contra un catálogo global.

La captura exige identidades existentes y un mapa completo de modelos; no genera GUID al exportar. Admite las caras planas convexas evaluadas de un contorno que acepta GeoCPU. Rechaza líneas/CAD no soportados, agujeros, curvas, topología inválida, datos incompletos o precisión que no pueda conservar; no omite objetos silenciosamente. No conserva todavía recetas paramétricas completas, colores por cara, restricciones, fórmulas ni tipos/anidados como una familia editable.

### Snapshot, retención y publicación

La escritura captura geometría, catálogo, unidades y nombre antes del primer puente de paquetes, cuya espera usa `DoEvents`. El paquete representa ese snapshot; la API no completa partes leyendo después el contexto activo ni cambia `RutaArchivo`/`Modificado` al terminar.

La lectura copia primero el archivo a una carpeta propia nueva y verifica SHA256 antes/después de la copia. Valida y extrae esa copia, no vuelve a interpretar el original. La huella se calcula con bloques de 64 KiB mediante `ReadFile`, sin cargar el ZIP completo en un `Byte()` o stream de memoria de VB6.

Al guardar una edición se verifica la copia ZIP base, se vuelve a extraer a un staging nuevo y se sustituye únicamente `modelo/geometria.xml`. El resto conserva sus bytes: manifiesto, relaciones, descriptor, catálogos, unidades, recursos y partes opcionales desconocidas. No regenerar el manifiesto del paquete leído. Las huellas protegen la copia privada durante su uso; no invalidan una edición manual legítima realizada antes de abrir el documento.

Las partes o secciones desconocidas con `required="true"` rechazan la preparación. Si `required` falta, se trata de una parte opcional mediante consulta segura del atributo, sin convertir `Null`. Los datos opcionales desconocidos requieren aceptación y se conservan sin ejecutarse. Un contenedor futuro se advierte antes de preparar sus datos CPU. El núcleo geométrico sigue siendo estricto: no aceptar atributos/nodos arbitrarios que cambien su contrato. Los ID de parámetros adicionales sólo caben si mantienen la estructura y tipos admitidos.

Ambos guardados requieren un destino nuevo. El trabajador termina un candidato en una carpeta privada vecina al destino; `MoveFileW` realiza la publicación sin reemplazo. Si otro archivo aparece antes de publicar, la operación falla y conserva ese archivo. No basta con comprobar `FileExists` antes de empaquetar. Este incremento no implementa Guardar sobre un archivo previamente abierto ni la resolución de cambios externos desde su versión de apertura.

El preparado conserva su staging mientras sus DTO y recursos lo necesiten. No borra directorios en el destructor. El anfitrión debe retirarlo sólo después de cerrar los consumidores y verificar la propiedad de esas rutas. La limpieza del candidato se limita al archivo y carpeta vacía creados por la operación; no hay borrado recursivo de rutas del usuario.

### Validación propia de la 1.5.430

El optativo `COBRA_PRUEBA_PGC1=1` se engancha al final de `/prueba_documentos`, conservando sus 240 criterios y su log. `prueba_documento_geometrico.log` contiene un banco separado de 37 criterios. El contrato de éxito exige `PGC01..PGC37` únicos/en orden, un solo `TOTAL: 37 FALLOS: 0`, `ESPERADAS: 37` y `FIN DOCUMENTO_GEOMETRICO_PGC1`. Son 43 filas no vacías; 44 al dividir el CRLF final. Cualquier fallo, excepción, log ausente/incompleto, diagnóstico nuevo o salida nativa no 0 rechaza.

Las fixtures crean dos World privados por las APIs normales, con nombres e ID locales iguales y catálogos/recursos/unidades distintos. El ciclo captura A, empaqueta, mueve el archivo, retira los recursos externos, prepara, compara geometría/GUID/parámetros/volumen y recursos por SHA, edita CPU, guarda y reabre. También comprueba retención literal de extensiones futuras, partes/secciones opcionales sin `required`, rechazo semántico, dueño incorrecto, recurso faltante, staging ocupado, base alterada, destino existente y colisión después de terminar el candidato. La limpieza verifica que sólo se cierran auxiliares y se restituyen Mundo/CFG/UP/selección/WGL/foco principales.

El resultado propio de430 es PGC37/0 más Documentos240/0, con cinco bancos focalizados que suman439/0. El recibo P2/RECIBO_PGC37.json acredita salida nativa natural0, cadena de ambosZIP,223fuentes y huellas/perfiles/semilla/entorno/diagnósticos constantes. GEO41 ya está incluido en240. No heredar resultados de otras versiones ni llamarlo suite13. Tres altas VBP llevan la base de 219 declaraciones a 222; con VBP son 223 fuentes, más el recurso declarado aparte. No heredar 220 ni un número de versión de otro corte.

Después de acreditar PGC1, el siguiente paso es una materialización y publicación por propietario que no use los constructores gráficos/globales actuales como si fueran CPU. El aislamiento completo de selección, editores, historial, vistas, planos, recorridos, familias y resultados sigue pendiente antes de habilitar otro PTRM. La futura fase de ray tracing permanece fuera de este incremento.

## Próximo paso de formatos, todavía sin implementar

Preparar una proyección gráfica provisional del documentoCPU admitido, con propietario y retirada/rollback individuales; conservar el preparado original y el ZIP como autoridad. No adjuntar un formulario al ContextoCPU: la API exige que siga no registrado y sin modelos/formularios. Crear_Formulario actualmente registra otro contexto implícito y la inicialización siembra geometría demo; ambas rutas requieren un contrato productivo explícito antes de publicar sesiones.

No reemplazar el XMLCPU por una recaptura de World: el capturador actual sólo exporta siete parámetros y transformación identidad. La proyección debe cotejar posiciones/IDs/materiales sin perder parámetros adicionales, transformaciones ni precisiónDouble. Empezar con prueba paquete movido→World propio→BMP→rollback, incluyendo fallos tras registro/GL/materialización. Después, diseñar sesión y comandos sincronizados con el núcleo. No llamar PTRM completo a esa futura vista limitada.


## Antecedentes conservados

La sección Estado al20/10/2026 y las limitaciones anteriores que siguen son historia; prevalece el estado430 anterior. Se conserva su texto para trazabilidad.


**Estado al20/10/2026.** Base comprobada seleccionada enF5: **1.5.412**, con838/0 propios focalizados; entrega activa1.5.242 conservada. El núcleoCPU de geometría por documento se integró y pasóGCPU32/GADV9 dentro deDocumentos240/0, además de los otros cuatro bancos. Esto no demuestra apertura/guardado semántico completo ni aislamiento multiproyecto. El contenedorZIP, recursos de configuración, identidades iniciales eiconos/asociaciones siguen siendo fundamentos implementados. Los resultadosDocumentos37/0 yservicio96/0 pertenecen a1.5.385 yno son resultados nuevos de412.

El usuario cambió `.ctr` por `.ctrm` y exige varios proyectos en una sola ventana. Al corte412 todavía no están habilitados el guardado/apertura completos CTRM/PTRM ni el aislamiento multiproyecto. Se desarrollan y prueban en la continuación de [los 26 pendientes](AVANCE_26_PENDIENTES.md), sin presentarlos como terminados por validar solo ZIP/recursos. Los límites gráficos y de rendimiento conservan su evidencia propia; consultar la [auditoría 395](../Auditorias/PROFUNDIDAD_NIVELES_FRANJA_20261018.md).

Unidades por contexto y sus consumidores iniciales tienen1070/0 propios de400; el servicio de configuración por documento y el vínculo de vistas se validaron antes en399. Estos avances no habilitan aún un segundoPTRM. Ver [auditoría de unidades](../Auditorias/UNIDADES_POR_DOCUMENTO_20261018.md).

## Decisiones del usuario

- `.ctrm`: familia paramétrica reutilizable, con varios tipos y componentes anidados; geometría, propiedades BIM, parámetros, fórmulas y restricciones editables.
- `.ptrm`: proyecto completo, autocontenido y portátil. Incluye definiciones de componentes cargados y sus recursos, imágenes/texturas, modelo, vistas, planos, cámaras, recorridos, apariencias, configuración y datos de entrada/salida BIM.
- Ambos son paquetes ZIP reales, con estructura documentada. El usuario puede extraerlos, editar datos y recomprimirlos; TRAMA debe validar el resultado al abrir.
- Abrir otro PTRM crea un proyecto independiente; no incorpora automáticamente sus datos al proyecto activo. Importar y abrir son operaciones distintas.
- Cada proyecto conserva su configuración técnica, vistas y distribución de ventanas. El idioma y el tema siguen siendo preferencias del usuario.
- Revit: objetivo futuro de importar RVT y RFA sin Revit instalado, conservando geometría y propiedades BIM, además de tipos, parámetros, fórmulas y restricciones editables. Su fidelidad debe demostrarse por capacidades/categorías; no prometer compatibilidad universal antes de validarla.
- La selección de biblioteca y su condición comercial se decidirán en la fase futura de compatibilidad Revit. No se ha contratado ni elegido un SDK.
- Babel se integrará más adelante como sección de análisis y diseño estructural. Esta etapa no solicita convertir proyectos BBL existentes; se aprovecha su estructura como referencia.

## Compatibilidad entre versiones — requisito confirmado

El usuario pide conservar siempre la estructura de geometría y propiedades/parámetros básicos. Los documentos nuevos declaran `coreSchemaVersion="1"`: ese núcleo estable debe permanecer interpretable aunque el formato general y la aplicación evolucionen. `formatVersion` y `producerVersion` son conceptos distintos. Los contenedores iniciales 1.0 sin el atributo explícito se leen como núcleo 1.

Las novedades se añaden como parámetros o partes opcionales, sin sustituir las coordenadas, topología, identidades y propiedades básicas. Antes de materializar un archivo futuro debe mostrarse una advertencia de compatibilidad. La versión actual podrá ignorar en su interfaz las novedades que no entiende y conservar sus bytes/relaciones al volver a guardar; ignorar no significa borrar ni ejecutar contenido desconocido. Los parámetros básicos y sus unidades deben seguir disponibles.

El servicio devuelve `NeedsCompatibilityWarning` y elementos `Warning`. El puente VB6 exige aceptación explícita antes de extraer un contenedor futuro. Esto valida contenedor/retención; no demuestra todavía que el lector de geometría aplique esa política. El futuro controlador de documentos debe implementar la advertencia visible y la conservación de datos desconocidos en el ciclo editar/guardar.

Un documento que declare un núcleo incompatible, esté corrupto o no permita verificar sus datos básicos no se abrirá como si estuviera completo: se informará el motivo y se preservará el original. Mantener el núcleo 1 en futuras versiones es la regla de diseño que permite la compatibilidad solicitada; no se puede prometer recuperar cualquier archivo arbitrario que cambie ese contrato.

Babel aporta secciones útiles para datos estructurales, pero necesita este contrato de núcleo/extensiones y preservación de novedades. No garantiza por sí solo la compatibilidad futura ni se incorpora ahora su módulo de análisis.

## Referencia revisada

Se inspeccionó directamente como ZIP `C:/Users/HP/OneDrive/Escritorio/Libro1.xlsx`, sin renombrarlo ni modificarlo. Contiene 15 partes: tipos de contenido, relaciones, libro/hoja, estilos/tema, cadenas, dibujo/imagen y propiedades. SHA256: 92DD9CEA9F8CFEA3C58830AC714A15EA57F390E32277FB4AF957F0B985A04849. Se toma la separación por partes y relaciones, no la semántica de Excel ni un formato de macros.

## Contrato inicial del paquete

Partes iniciales del contenedor: `manifest.xml` y `proyecto/documento.xml` o `componente/documento.xml` según el tipo. Ampliación de datos prevista: `modelo/`, `componentes/<id>/`, `vistas/`, `planos/`, `configuracion/`, `sesion/ventanas.xml`, `recursos/`, `localizacion/`, `estudios/`, `resultados/` e `interoperabilidad/`.

El manifiesto identifica tipo de documento, identidad persistente, versión del esquema y partes/relaciones. La versión del esquema se distingue de la versión del programa. XML UTF-8 es la propuesta para datos editables; imágenes, texturas y resultados grandes conservan archivos binarios separados. Los nombres internos se mantienen estables y las etiquetas del usuario admiten Unicode.

Identidades persistentes separan proyecto, familia, tipo, instancia, vista y recurso. Los índices de colecciones, HWND y contextos GL son datos de ejecución, nunca identidades del documento. Los nombres visibles pueden repetirse entre proyectos sin mezclarlos.

Las familias anidadas son relaciones entre definiciones e instancias, con transformación y valores propios. Dentro de PTRM se propone guardar sus partes expandidas y relacionadas por identidad; exportar CTRM produce un paquete autónomo. No es necesario encadenar ZIP dentro de ZIP en memoria.

La edición manual válida debe aceptarse. Validar ZIP/CRC estándar, versión, estructura, tipos de datos, identidades, referencias y disponibilidad de recursos; no exigir una huella SHA privada inmutable que invalide cualquier modificación legítima. Los errores deben localizar la parte y el dato afectados. Una apertura fallida conserva los proyectos abiertos y el archivo original.

## Contexto independiente por proyecto

El primer cambio estructural debe ser un ContextoProyecto que posea Mundo/modelo, catálogos, familias/tipos/instancias, referencias, unidades, configuración, vistas/planos, cámaras/recorridos/renders, datos BIM, recursos, resultados, historial, estado modificado y layout.

Cada ventana queda ligada a su contexto y vista antes de crear su contexto GL. Activar un proyecto actualiza cinta, navegador y propiedades; cada render, evento y temporizador conserva el contexto de su propia ventana aunque otro proyecto esté activo. Cambiar solamente el Mundo global al activar una pestaña no ofrece aislamiento.

La lectura crea un documento temporal, valida todas sus partes y relaciones, y solo después publica el nuevo contexto y sus vistas. Cerrar un proyecto o fallar al abrirlo no limpia colecciones compartidas de los demás. La distribución guardada se adapta al área disponible y evita ventanas fuera de los monitores actuales. Idioma/tema y selección de hardware permanecen en el perfil personal.

## Guardado y lectura

Guardar en un paquete temporal, finalizarlo, validarlo y reemplazar el destino conservando respaldo. El fallo mantiene el archivo anterior y el estado modificado del documento. Comprobar cambios externos antes de sobrescribir; no reemplazar silenciosamente una edición ajena.

Leer/escribir entradas por bloques y recursos a demanda; no cargar el ZIP completo en un Byte() de VB6. Servicio implementado para el contenedor: trabajador .NET separado con System.IO.Compression, compilado y empaquetado por el pipeline. Los lectores semánticos del modelo siguen pendientes. Evitar Update y streams no posicionables que puedan cargar archivos completos en memoria. Los límites y CRC tienen pruebas propias del servicio; la cobertura del documento completo requiere las pruebas pendientes de sus serializadores.

No cambiar cabeceras ni eliminar lectores de formatos TRAMA/Cobra anteriores. Adaptar lectores existentes al contexto temporal y ofrecer guardado en el formato nuevo sin alterar el original por el mero hecho de abrirlo.

## Base existente y orden de trabajo

TRAMA ya escribe TRAMA_PROYECTO1 por seis secciones y TRAMA_SOLIDOS1 para sólidos/componentes. Reutilizar serializadores y reemplazo seguro; ampliar cobertura de recursos/configuración. Proyecto_Abrir actual agrega al modelo0 por secciones y carece de rollback global: no usarlo directamente como apertura multiproyecto.

Babel guarda texto por secciones con configuración, unidades, materiales, geometría estructural, cargas, combinaciones y resultados; sus texturas incorporadas y separación de datos sirven de referencia. No copiar sus límites Integer ni su manejo permisivo de errores.

1. Contexto inicial e identidades de vistas incorporados; completar la encapsulación de todos sus estados sin cambiar el comportamiento.
2. Asociar vistas, render, selección, editores, historial y catálogos a sus contextos.
3. Servicio ZIP y validación independiente implementados como fundamento; completar contrato/validación semántica del núcleo geométrico.
4. Integrar todos los serializadores, recursos y familias anidadas; abrir/guardar proyectos independientes.
5. Validar aislamiento entre proyectos y compatibilidad anterior antes de habilitar el flujo normal.
6. Integraciones posteriores: Babel como módulo estructural; importación Revit según tecnología y cobertura verificadas.

## Adaptación comprobada de Babel V3.0

La revisión de sus fuentes activos está en `Documentos/Auditorias/ADAPTACION_BABEL_CTRM_PTRM_20261017.md`; fue solo de lectura, sin ejecutar Babel ni probar conversiones.

| Base de Babel | Adaptación al documento TRAMA |
| --- | --- |
| Nodos, miembros, secciones, áreas y propiedades mecánicas | Extensión estructural versionada, relacionada con objetos del núcleo geométrico independiente. |
| Niveles/ejes, unidades y configuración de hasta cuatro vistas | Partes de proyecto con identidades persistentes; sin heredar el límite de cuatro ventanas ni las preferencias personales. |
| Materiales y texturas incorporadas | Recursos binarios internos y referencias por identidad; evitar grandes cadenas Base64. |
| Cargas, combinaciones, análisis y resultados de áreas | Conservar revisión del modelo, malla evaluada e identidades de sus elementos. Regenerar la malla no garantiza que resultados previos sigan referidos al mismo elemento. |
| Bloques que hoy apuntan a otros BBL | Definiciones e instancias autocontenidas con tipos, parámetros, transformaciones y validación del grafo. El bloque actual no equivale a una familia anidada CTRM. |

No copiar el lector BBL como contrato del paquete: depende del orden (termina en TEXTURAS), usa referencias posicionales y no conserva secciones desconocidas. Tampoco restituye literalmente todos los campos de áreas. Hace falta lectura a datos temporales, validación completa, IDs persistentes y retención de extensiones. Esta adaptación no incorpora ahora el analizador de Babel ni ofrece importación BBL operativa.

## Criterios de aceptación

Probar dos proyectos con nombres/IDs locales iguales y materiales/unidades diferentes; alternarlos, editarlos, guardarlos y cerrar uno sin afectar al otro. Verificar ventanas inactivas, cámaras, deshacer, familias/tipos/anidados y disposición de vistas.

Mover PTRM/CTRM a otro equipo sin sus carpetas originales y comprobar recursos. Extraer, editar UTF-8, recomprimir y reabrir datos válidos. Rechazar ZIP/relaciones/datos inválidos sin modificar archivos ni sesiones existentes. Verificar versiones, fallos de escritura, respaldos y formatos anteriores. Ejecutar las regresiones y comprobaciones visuales apropiadas con compilaciones versionadas; no atribuir al formato nuevo los bancos de 1.5.382.

Las futuras secciones de análisis/resultados deben tener contratos de datos versionados y conservar datos no interpretados, o impedir su sobrescritura, para evitar pérdidas al abrir con otra versión o sin un módulo.

## Referencias técnicas

- Microsoft, estructura SpreadsheetML: https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/structure-of-a-spreadsheetml-document
- Microsoft, modos ZIP y memoria: https://learn.microsoft.com/en-us/dotnet/api/system.io.compression.ziparchivemode?view=netframework-4.8.1
- Microsoft, reemplazo con respaldo: https://learn.microsoft.com/en-us/dotnet/api/system.io.file.replace?view=netframework-4.8.1

La estructura de rutas, esquema exacto, cuotas y tecnología del servicio son propuestas técnicas iniciales; las decisiones funcionales anteriores provienen de la entrevista. El servicio ZIP y el puente ya existen, pero el guardado/apertura completos de los modelos CTRM/PTRM todavía no están habilitados. No se han comprado bibliotecas.

Actualización403: consumidores de configuración por dueño, cachés A/B/A y rechazo offline tienen1101/0 propios junto a unidades/documentos. No habilita todavía un segundoPTRM ni guardado semántico completo. La propuesta de referenciasCPU68 aún no se integra.

Actualización1.5.405: el núcleo de referencias y perfiles CPU pasó sus72criterios propios, junto al prefijo127 de Documentos. La tanda completa dio1177/0. Cuotas y lectura temporal están implementadas; aún no se migran todos los comandos de interfaz ni se materializa un PTRM completo. Ver [auditoría de referencias CPU](../Auditorias/REFERENCIAS_CPU_20261018.md).


## Incremento geométrico comprobado en412

El servicioCPU ligado aidentidad decontexto yWorld conserva elXMLoriginal sin reformatearlo al leer/guardar, valida un candidato completo antes de publicarlo yrechaza ediciones que no puedan conservar exactamente el valorDouble. Admite en este incremento matrices afines ycaras planas convexas de un contorno exterior; las cuotas ypropiedad deldocumento tienen pruebas realesGCPU32/GADV9. No es unBRep general ni reconstruye curvas/huecos/recetas, yno está conectado aún a captura deWorld o materialización gráfica delpaquete. No habilitar un segundoPTRM hasta migrar todos sus consumidores y completar las pruebas multisección. Auditoría [geometría yperfiles412](../Auditorias/NUCLEO_GEOMETRIA_Y_PERFILES_412_20261020.md).
