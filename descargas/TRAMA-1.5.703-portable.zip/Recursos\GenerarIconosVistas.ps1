Add-Type -AssemblyName System.Drawing
Add-Type -Namespace Babel.Native -Name User32 -MemberDefinition @'
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    public static extern bool DestroyIcon(System.IntPtr handle);
'@

$outputDirectory = Join-Path $PSScriptRoot 'Vistas'
[IO.Directory]::CreateDirectory($outputDirectory) | Out-Null

$white = [Drawing.Color]::White
$outline = [Drawing.Color]::FromArgb(68, 82, 98)
$fill = [Drawing.Color]::FromArgb(222, 230, 238)
$fillDark = [Drawing.Color]::FromArgb(182, 195, 208)
$accent = [Drawing.Color]::FromArgb(49, 132, 178)
$gold = [Drawing.Color]::FromArgb(210, 164, 72)
$green = [Drawing.Color]::FromArgb(64, 148, 108)

$icons = @(
    'vista_plano_estructural',
    'vista_3d',
    'vista_alzado',
    'vista_seccion',
    'vista_detalle',
    'vista_render',
    'vista_diseno',
    'vista_tabla_grafica',
    'vista_leyenda',
    'vista_tabla',
    'vista_plano',
    'vista_familia',
    'vista_cielo_raso'
)

function New-Pen([Drawing.Color]$color, [single]$width = 1.0) {
    $pen = New-Object Drawing.Pen($color, $width)
    $pen.StartCap = [Drawing.Drawing2D.LineCap]::Round
    $pen.EndCap = [Drawing.Drawing2D.LineCap]::Round
    $pen.LineJoin = [Drawing.Drawing2D.LineJoin]::Round
    return $pen
}

function Save-BabelIcon([string]$name) {
    $bitmap = New-Object Drawing.Bitmap 16, 16, ([Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $graphics.Clear($white)
    $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $pen = New-Pen $outline 1.15
    $thin = New-Pen $outline 0.85
    $accentPen = New-Pen $accent 1.35
    $goldPen = New-Pen $gold 1.2
    $greenPen = New-Pen $green 1.1
    $brush = New-Object Drawing.SolidBrush($fill)
    $darkBrush = New-Object Drawing.SolidBrush($fillDark)
    $accentBrush = New-Object Drawing.SolidBrush($accent)
    $goldBrush = New-Object Drawing.SolidBrush($gold)
    $greenBrush = New-Object Drawing.SolidBrush($green)

    switch ($name) {
        'vista_plano_estructural' {
            $graphics.FillRectangle($brush, 2, 2, 12, 12)
            $graphics.DrawRectangle($pen, 2, 2, 12, 12)
            foreach ($x in @(5, 8, 11)) { $graphics.DrawLine($thin, $x, 3, $x, 13) }
            foreach ($y in @(5, 8, 11)) { $graphics.DrawLine($thin, 3, $y, 13, $y) }
            $graphics.DrawLine($accentPen, 2, 8, 14, 8)
            $graphics.FillEllipse($goldBrush, 6.6, 6.6, 2.8, 2.8)
        }
        'vista_3d' {
            $top = [Drawing.PointF[]]@((New-Object Drawing.PointF(8,1.5)),(New-Object Drawing.PointF(13.5,4.7)),(New-Object Drawing.PointF(8,8)),(New-Object Drawing.PointF(2.5,4.7)))
            $left = [Drawing.PointF[]]@((New-Object Drawing.PointF(2.5,4.7)),(New-Object Drawing.PointF(8,8)),(New-Object Drawing.PointF(8,14)),(New-Object Drawing.PointF(2.5,10.8)))
            $right = [Drawing.PointF[]]@((New-Object Drawing.PointF(8,8)),(New-Object Drawing.PointF(13.5,4.7)),(New-Object Drawing.PointF(13.5,10.8)),(New-Object Drawing.PointF(8,14)))
            $graphics.FillPolygon($brush, $top); $graphics.FillPolygon($darkBrush, $left); $graphics.FillPolygon($accentBrush, $right)
            $graphics.DrawPolygon($pen, $top); $graphics.DrawPolygon($pen, $left); $graphics.DrawPolygon($pen, $right)
        }
        'vista_alzado' {
            $roof = [Drawing.PointF[]]@((New-Object Drawing.PointF(2,7)),(New-Object Drawing.PointF(8,2)),(New-Object Drawing.PointF(14,7)))
            $graphics.FillPolygon($darkBrush, $roof); $graphics.DrawPolygon($pen, $roof)
            $graphics.FillRectangle($brush, 4, 7, 8, 6); $graphics.DrawRectangle($pen, 4, 7, 8, 6)
            $graphics.DrawLine($accentPen, 8, 1, 8, 14)
            $graphics.FillEllipse($goldBrush, 6.7, 6, 2.6, 2.6)
        }
        'vista_seccion' {
            $graphics.DrawEllipse($pen, 2, 3, 8, 8)
            $graphics.FillPie($darkBrush, 2.5, 3.5, 7, 7, 90, 180)
            $graphics.DrawLine($accentPen, 9, 2, 9, 14)
            $graphics.DrawLine($goldPen, 9, 4, 14, 4)
            $graphics.DrawLine($goldPen, 9, 12, 14, 12)
        }
        'vista_detalle' {
            $dash = New-Pen $outline 1.0; $dash.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
            $graphics.DrawRectangle($dash, 2, 4, 9, 9)
            $graphics.DrawEllipse($accentPen, 9, 1.5, 5, 5)
            $graphics.DrawLine($goldPen, 10.5, 6, 8, 9)
            $dash.Dispose()
        }
        'vista_render' {
            $graphics.FillRectangle($brush, 2, 4, 12, 8); $graphics.DrawRectangle($pen, 2, 4, 12, 8)
            $graphics.FillEllipse($darkBrush, 5, 5, 6, 6); $graphics.DrawEllipse($pen, 5, 5, 6, 6)
            $graphics.FillEllipse($accentBrush, 7, 7, 2, 2)
            $graphics.DrawLine($goldPen, 12, 1, 12, 4); $graphics.DrawLine($goldPen, 10.5, 2.5, 13.5, 2.5)
        }
        'vista_diseno' {
            $graphics.FillRectangle($brush, 2, 2, 9, 12); $graphics.DrawRectangle($pen, 2, 2, 9, 12)
            $graphics.DrawLine($thin, 4, 5, 9, 5); $graphics.DrawLine($thin, 4, 7.5, 9, 7.5)
            $graphics.DrawLine($accentPen, 7, 12.5, 14, 5.5)
            $graphics.FillPolygon($goldBrush, [Drawing.PointF[]]@((New-Object Drawing.PointF(6.5,13)),(New-Object Drawing.PointF(8,12.5)),(New-Object Drawing.PointF(7,11.5))))
        }
        'vista_tabla_grafica' {
            $graphics.FillRectangle($brush, 2, 2, 12, 12); $graphics.DrawRectangle($pen, 2, 2, 12, 12)
            $graphics.DrawLine($thin, 2, 6, 14, 6); $graphics.DrawLine($thin, 6, 6, 6, 14)
            $graphics.FillRectangle($accentBrush, 7, 10, 1.8, 3); $graphics.FillRectangle($greenBrush, 9.5, 8, 1.8, 5); $graphics.FillRectangle($goldBrush, 12, 7, 1.4, 6)
            $graphics.DrawLine($thin, 3, 4, 12, 4)
        }
        'vista_leyenda' {
            $graphics.FillRectangle($brush, 2, 2, 12, 12); $graphics.DrawRectangle($pen, 2, 2, 12, 12)
            $graphics.FillEllipse($accentBrush, 4, 4, 2.5, 2.5); $graphics.DrawLine($thin, 8, 5.2, 12, 5.2)
            $graphics.FillRectangle($goldBrush, 4, 8, 2.5, 2.5); $graphics.DrawLine($thin, 8, 9.2, 12, 9.2)
            $graphics.DrawLine($greenPen, 4, 12, 6.5, 12); $graphics.DrawLine($thin, 8, 12, 12, 12)
        }
        'vista_tabla' {
            $graphics.FillRectangle($brush, 2, 3, 12, 10); $graphics.DrawRectangle($pen, 2, 3, 12, 10)
            foreach ($x in @(6, 10)) { $graphics.DrawLine($thin, $x, 3, $x, 13) }
            foreach ($y in @(6, 9)) { $graphics.DrawLine($thin, 2, $y, 14, $y) }
            $graphics.FillRectangle($accentBrush, 2.5, 3.5, 11, 2)
        }
        'vista_plano' {
            $graphics.FillRectangle($darkBrush, 2, 4, 9, 9); $graphics.DrawRectangle($pen, 2, 4, 9, 9)
            $graphics.FillRectangle($brush, 5, 2, 9, 9); $graphics.DrawRectangle($pen, 5, 2, 9, 9)
            $graphics.DrawRectangle($accentPen, 7, 4, 5, 4)
            $graphics.DrawLine($goldPen, 7, 9.5, 12, 9.5)
        }
        'vista_familia' {
            $graphics.FillRectangle($brush, 2, 8, 6, 6); $graphics.DrawRectangle($pen, 2, 8, 6, 6)
            $graphics.FillRectangle($darkBrush, 8, 2, 6, 6); $graphics.DrawRectangle($pen, 8, 2, 6, 6)
            $graphics.DrawLine($accentPen, 8, 5, 5, 5); $graphics.DrawLine($accentPen, 5, 5, 5, 8)
            $graphics.FillEllipse($goldBrush, 4, 4, 2, 2)
        }
        'vista_cielo_raso' {
            $graphics.FillRectangle($brush, 2, 2, 12, 12); $graphics.DrawRectangle($pen, 2, 2, 12, 12)
            foreach ($n in @(5, 8, 11)) { $graphics.DrawLine($thin, $n, 3, $n, 13); $graphics.DrawLine($thin, 3, $n, 13, $n) }
            $graphics.FillEllipse($goldBrush, 6, 6, 4, 4); $graphics.DrawEllipse($accentPen, 5, 5, 6, 6)
        }
    }

    $bmpPath = Join-Path $outputDirectory ($name + '.bmp')
    $pngPath = Join-Path $outputDirectory ($name + '.png')
    $icoPath = Join-Path $outputDirectory ($name + '.ico')
    $bitmap.Save($bmpPath, [Drawing.Imaging.ImageFormat]::Bmp)
    $bitmap.Save($pngPath, [Drawing.Imaging.ImageFormat]::Png)
    $iconHandle = $bitmap.GetHicon()
    $icon = [Drawing.Icon]::FromHandle($iconHandle)
    $iconStream = [IO.File]::Open($icoPath, [IO.FileMode]::Create)
    try {
        $icon.Save($iconStream)
    }
    finally {
        $iconStream.Dispose()
        $icon.Dispose()
        [Babel.Native.User32]::DestroyIcon($iconHandle) | Out-Null
    }

    foreach ($resource in @($pen, $thin, $accentPen, $goldPen, $greenPen, $brush, $darkBrush, $accentBrush, $goldBrush, $greenBrush)) { $resource.Dispose() }
    $graphics.Dispose()
    $bitmap.Dispose()
}

foreach ($icon in $icons) { Save-BabelIcon $icon }

$preview = New-Object Drawing.Bitmap 640, 280, ([Drawing.Imaging.PixelFormat]::Format24bppRgb)
$previewGraphics = [Drawing.Graphics]::FromImage($preview)
$previewGraphics.Clear([Drawing.Color]::FromArgb(244, 246, 249))
$previewGraphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$previewFont = New-Object Drawing.Font('Segoe UI', 8.5)
$previewText = New-Object Drawing.SolidBrush($outline)
$previewBorder = New-Pen ([Drawing.Color]::FromArgb(205, 214, 224)) 1
for ($index = 0; $index -lt $icons.Count; $index++) {
    $column = $index % 4
    $row = [Math]::Floor($index / 4)
    $left = 10 + ($column * 157)
    $top = 10 + ($row * 67)
    $previewGraphics.FillRectangle([Drawing.Brushes]::White, $left, $top, 147, 57)
    $previewGraphics.DrawRectangle($previewBorder, $left, $top, 147, 57)
    $sourceIcon = [Drawing.Image]::FromFile((Join-Path $outputDirectory ($icons[$index] + '.png')))
    $previewGraphics.DrawImage($sourceIcon, $left + 8, $top + 5, 48, 48)
    $previewGraphics.DrawString($icons[$index].Replace('vista_', '').Replace('_', ' '), $previewFont, $previewText, $left + 62, $top + 20)
    $sourceIcon.Dispose()
}
$preview.Save((Join-Path $outputDirectory 'muestrario_iconos_vistas.png'), [Drawing.Imaging.ImageFormat]::Png)
$previewBorder.Dispose(); $previewText.Dispose(); $previewFont.Dispose(); $previewGraphics.Dispose(); $preview.Dispose()

Write-Output ("Generados {0} iconos Babel en {1}" -f $icons.Count, $outputDirectory)
