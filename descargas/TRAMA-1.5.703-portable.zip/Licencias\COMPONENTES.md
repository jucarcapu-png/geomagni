# Componentes de ejecución

- Cobra Akira, CobraGLBridge y MouseHunter: componentes presentes en el proyecto recibido. Se conservan sus autorías y condiciones originales.
- MSCOMCTL.OCX, MSCOMCT2.OCX, MSSTDFMT.DLL: controles de Microsoft Visual Basic 6; figuran en el REDIST.TXT de la instalación de Visual Studio del propietario, incluido como referencia. Se distribuyen localmente mediante manifiesto COM.
- Mesa 26.2.1, compilación MSVC x86 de mesa-dist-win: `opengl32.dll` y `libgallium_wgl.dll`. Solo se usan dentro del proceso de respaldo. Descarga: https://github.com/pal1000/mesa-dist-win/releases/tag/26.2.1 . Documentación de LLVMpipe: https://docs.mesa3d.org/drivers/llvmpipe.html . Licencia y avisos Mesa: `Mesa-license.html`; LLVM: `LLVM-LICENSE.txt`.
- Windows proporciona las bibliotecas del sistema y el runtime VB6. El selector y el instalador usan .NET Framework 4.x del sistema.

No se incluyen controladores AMD, Intel ni NVIDIA. No se utiliza instalación global de Mesa ni registro COM global.

## Fuentes de la marca

- **Inter** y **Sora**: SIL Open Font License 1.1 (`OFL-Inter.txt` y `OFL-Sora.txt`). En las Inter se ajustaron las métricas de línea de Windows, sin tocar los contornos; ver `FUENTES_TRAMA.txt`.
