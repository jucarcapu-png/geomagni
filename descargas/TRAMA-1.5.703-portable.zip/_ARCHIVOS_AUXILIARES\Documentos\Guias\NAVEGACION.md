# Cámaras y rueda de navegación

<!-- VIGENCIA_DOC23_20261018 -->
**Corte de referencia: 18/10/2026, candidata 1.5.395; entrega activa 1.5.242.** La candidata no sustituye la instalación activa. Los cambios nuevos requieren su propia compilación y pruebas. Los [26 pendientes y sus criterios](AVANCE_26_PENDIENTES.md) son la lista de continuidad; esta revisión de guías corresponde al n.º 23 y no cierra los otros requisitos.

La cámara de dos clics, reproducción sincronizada y los siete modos de rueda ya existen. El anclaje/desanclaje es individual. En395 se observó profundidad del nivel en reposo y tras soltar el ViewCube; eso no acredita continuidad completa ni Shift+botón central físico. Véase [la revisión 395](../Auditorias/PROFUNDIDAD_NIVELES_FRANJA_20261018.md).
<!-- FIN_VIGENCIA_DOC23_20261018 -->

## Ver el recorrido desde dos ventanas

Abra una vista 3D y la vista del recorrido. Sepárelas mediante Mosaico o arrastrando una pestaña hacia un borde del otro grupo. Pulse **Reproducir** en el recorrido: la cámara azul avanza por el camino en la vista del modelo mientras la ventana del recorrido presenta la imagen del mismo fotograma. La vista del observador conserva su orientación y su zoom.

## Colocar una cámara

1. Active una vista del modelo y abra **VISTA → Cámara**.
2. Elija el nivel y el desfase de altura en la banda contextual.
3. Haga clic para colocar el ojo. La previsualización permite orientar la cámara.
4. Haga clic en el destino. Puede cambiar el nivel y el desfase antes de este segundo clic.
5. Se abre la nueva cámara y queda registrada entre las vistas 3D del navegador.

En **Cámara** puede precisar las coordenadas, ángulos, giro, campo de visión y límites cercano y lejano. **Editar cámara en el modelo** permite cambiar ojo y destino con los controles del encuadre. **Guardar** conserva la cámara en un archivo `.tramacamara` (también admite el anterior `.cobracamara`); **Abrir recorrido** admite también esos archivos. Su formato conserva una sola cámara, sin convertirla en un recorrido de dos puntos.

## Usar la rueda

Pulse el botón circular superior de la barra de navegación, **F8** o **Mayús+W**. Mantenga pulsado un sector y arrastre. Escape cierra la rueda y cancela cualquier gesto en curso, restaurando la cámara anterior al gesto.

| Herramienta | Acción |
|---|---|
| Zoom | Acerca o aleja al arrastrar verticalmente. |
| Órbita | Gira alrededor del destino. |
| Encuadre | Traslada ojo y destino juntos. |
| Centrar | Define el centro de giro bajo el puntero. |
| Paseo | Avanza y se desplaza lateralmente mientras mantiene el botón pulsado. |
| Mirar | Cambia la dirección manteniendo fijo el ojo. |
| Arriba/abajo | Cambia la elevación del ojo y del destino. |
| Avanzar | Desplaza la cámara en la dirección de la mirada. |
| Rebobinar | Arrastre hacia la izquierda para recuperar una posición del historial de la rueda. |

El menú, accesible con el botón derecho o la flecha de la rueda, ofrece siete modos: completa, mini completa, mini de objeto, mini de edificio, básica de objeto, básica de edificio y 2D. El historial conserva hasta 30 posiciones con miniaturas, independientemente para cada ventana, durante la sesión.

**Opciones de rueda** permite guardar tamaño y opacidad de las ruedas grande y pequeña; ayudas; inversión del eje vertical de Mirar; paseo paralelo al suelo; velocidad; zoom por clic y mantenimiento de la verticalidad durante la órbita. Las ruedas básicas mantienen sus ayudas y zoom por clic activados.

En una cámara fija, los cambios realizados con la rueda actualizan su ojo y destino. En un recorrido actualizan la clave del fotograma mostrado o insertan una nueva clave si el fotograma no era una clave.

## Ventanas

Las cámaras usan el mismo gestor que las vistas, planos y recorridos. Al arrastrar una pestaña solo se separa esa vista. Puede volver a agruparla por la barra de pestañas o anclarla a los cuatro bordes. La ficha activa permanece blanca.

El ejemplo `Ejemplos/Recorrido-Ejercicio/Camara-dos-clics.cobracamara` se creó colocando el ojo y el destino con el ratón en el modelo de prueba de dos sólidos. Puede abrirlo con **Abrir recorrido**; se reconoce como cámara fija. El archivo contiene la cámara y su configuración, no la geometría del modelo.
