# Ejercicio real: cinco vistas sobre el plano

Abre **Ver ejercicio de planos** en el escritorio. La hoja A001 contiene **3D 1, Alzado 1, Tabla 1, Estructural 1 y Seccion 1**. Se guardó desde Cobra después de colocar y mover las vistas con el ratón.

## Cómo se hizo

1. Partí del plano con las tres primeras vistas.
2. Arrastré **Estructural 1** desde el navegador hasta el papel y solté el botón. Apareció solo el contorno del contenido, todavía sin añadir la vista.
3. Moví el puntero y confirmé con otro clic, superponiendo el dibujo con la vista existente para comprobar la transparencia.
4. Arrastré esa vista colocada hacia la parte superior derecha. El plano conserva su posición al guardar y reabrir.
5. Arrastré **Seccion 1**, cancelé una colocación con el botón derecho y repetí el gesto. La segunda colocación se confirmó en la parte inferior.
6. Guardé **Ejercicio-cinco-vistas-transparentes.tramaplanos**. Las capturas de abajo corresponden a esas acciones, antes de actualizar el nombre de la hoja.

## Capturas de la prueba

### Soltar inicia la colocación

![Recuadro pendiente de confirmar](01-recuadro-pendiente.jpg)

### Superposición transparente

![Vista añadida sobre otra sin un rectángulo blanco que la tape](02-vistas-superpuestas.jpg)

### Mover una vista colocada

![Vista movida con el ratón](03-vista-movida.jpg)

### Otra colocación pendiente

![Sección pendiente de confirmar](04-segunda-colocacion-pendiente.jpg)

### Cinco vistas confirmadas

![Composición con cinco vistas](05-cinco-vistas.jpg)

### Resaltado sin selección

![Al pasar el puntero se resalta solo el contenido y las propiedades siguen mostrando el plano](06-resaltado-sin-seleccion.jpg)

También se comprobó que Escape retira la colocación pendiente incluso cuando el foco está en la ventana principal: la hoja conserva sus cinco vistas.

### Ventana flotante

Se extrajo la pestaña A001 del grupo y se movió la ventana completa. Sus cinco vistas conservaron sus posiciones sobre la hoja.

![Plano en una ventana flotante](08-plano-flotante-completo.jpg)

## Para probarlo

- Pasa el puntero sobre una vista: se ilumina su contorno. Pulsa para seleccionarla y ver sus propiedades.
- Arrastra su interior para moverla; el recuadro indica el destino. Suelta para confirmar.
- Arrastra una vista desde el navegador, suelta sobre el papel y mueve el recuadro. Confirma con un clic adicional o cancela con Escape o botón derecho.
- Acerca el papel con la rueda para leer los rótulos. El zoom del papel no modifica la escala de las vistas.
- A 1:100, un metro del modelo ocupa 10 mm en papel; a 1:50 ocupa 20 mm. La escala pertenece a la vista de origen.

El archivo de planos guarda composición, posiciones y propiedades; la geometría procede del modelo abierto. El acceso del ejercicio prepara automáticamente el modelo de demostración.
